SHOPMALL PROFESSIONAL WEBSITE
1. Extract the ZIP.
2. Open index.html in Chrome or Edge.
3. The product pictures are local SVG files, so they work without external image links.
4. Search, category filters, wishlist buttons and Add to Cart are functional.
5. This is a front-end demo; real login, database, orders and payment need a backend.
